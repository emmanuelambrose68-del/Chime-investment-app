# Chime_Investment

A mobile-first Telegram Mini App starter for a legitimate investment-tracking interface.

## Included
- Telegram Web App SDK integration
- Responsive dashboard
- Demo balance and transaction UI
- Investment-plan cards
- Deposit/withdraw UI placeholders
- Demo-mode notice

## Important
This project does not process real money and does not create real investment returns. Before handling real user funds, add a secure backend, database, verified Telegram init-data validation, a legitimate payment provider, audit logs, access controls, and applicable financial/legal compliance.

## Deploy
Upload these files to a GitHub repository. Enable GitHub Pages from the `main` branch and root folder. The resulting HTTPS URL can later be configured as the Telegram Mini App URL.
