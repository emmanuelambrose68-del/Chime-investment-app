const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); }
const user = tg?.initDataUnsafe?.user;
if (user) {
  document.getElementById('welcome').textContent = `Welcome, ${user.first_name || 'User'}`;
  document.getElementById('avatar').textContent = ((user.first_name||'C')[0] + (user.last_name||'I')[0]).toUpperCase();
}
function showModal(type){
  document.getElementById('modalTitle').textContent = type === 'deposit' ? 'Deposit' : 'Withdraw';
  document.getElementById('modalText').textContent = 'This feature is disabled in the demo. Real-money transactions will only be added after secure backend, payment-provider and applicable compliance setup.';
  document.getElementById('modal').classList.remove('hidden');
}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
